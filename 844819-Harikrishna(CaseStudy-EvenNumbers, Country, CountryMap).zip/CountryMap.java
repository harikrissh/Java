import java.util.*;
class CountryMap{
	Map<String, String> M1=new HashMap<String, String>();
	
	public Map<String, String> storeCountryCapital(String CountryName, String Capital){
		M1.put(CountryName, Capital);
		return M1;
	}

	public String retrieveCapital(String CountryName){
		String found="";
		Iterator<Map.Entry<String, String>> itr = M1.entrySet().iterator(); 
		while(itr.hasNext()){
			Map.Entry<String, String> entry = itr.next(); 
			if((entry.getKey()).equals(CountryName)){
				found=entry.getValue();
				break;
			}
		}
		return found;
	}
	
	public String retrieveCountry(String Capital){
		String found="";
		Iterator<Map.Entry<String, String>> itr = M1.entrySet().iterator(); 
		while(itr.hasNext()){
			Map.Entry<String, String> entry = itr.next(); 
			if((entry.getValue()).equals(Capital)){
				found=entry.getKey();
				break;
			}
		}
		return found;
	}
	
	public Map<String, String> swapCountryCapital(){
		Map<String, String> M2=new HashMap<String, String>();
		Iterator<Map.Entry<String, String>> itr = M1.entrySet().iterator(); 	
		while(itr.hasNext()){
			Map.Entry<String, String> entry = itr.next(); 
			String ctry=entry.getKey();
			String cap=entry.getValue();
			M2.put(cap, ctry);
			}
		return M2;
	}
	
	public List<String> convertCountrytoArrayList(){
		List<String> L1=new ArrayList<String>();
		Iterator<String> itr = M1.keySet().iterator(); 
		while(itr.hasNext()){
			L1.add(itr.next());
			}
		return L1;
	}

	public static void main(String[] args){
		Scanner s=new Scanner(System.in);
		CountryMap cmap=new CountryMap();
		Map<String, String> mapObj=new HashMap<String, String>();

		System.out.println("Enter number of Country & Capital you want to add..");
		int num=s.nextInt();
		System.out.println("Enter country and capital names..");
		for(int i=0;i<num;i++){
			String ctry=s.next();
			String cap=s.next();
			mapObj=cmap.storeCountryCapital(ctry, cap);
		}
		System.out.println("\nCountries and Capitals added to HashMap..\n"+mapObj);

		System.out.println("\nEnter a Country to find Capital..");
		String findCap=s.next();
		String foundCap=cmap.retrieveCapital(findCap);
		if(foundCap!="")
			System.out.println("\n"+foundCap+" is capital of "+findCap);
		else
			System.out.println("\n"+findCap+" is not available in HashMap/invalid country.");

		System.out.println("\nEnter a Capital to find Country..");
		String findCtry=s.next();
		String foundCtry=cmap.retrieveCountry(findCtry);
		if(foundCtry!="")
			System.out.println("\n"+findCtry+" is in "+foundCtry);
		else
			System.out.println("\n"+findCtry+" is not available in HashMap/invalid capital.");

		System.out.println("\nPress Y to swap country(keys) and capital(values) in HashMap..");
		if(s.next().equalsIgnoreCase("Y")){
			mapObj=cmap.swapCountryCapital();
			System.out.println("\nAfter swapping..\n"+mapObj);
		}

		System.out.println("\nPress Y to convert countries in HashMap to ArrayList..");
		if(s.next().equalsIgnoreCase("Y")){
			List<String> listObj=new ArrayList<String>();
			listObj=cmap.convertCountrytoArrayList();
			System.out.println("\nAfter converting..\n"+listObj);
		}
	}
}
