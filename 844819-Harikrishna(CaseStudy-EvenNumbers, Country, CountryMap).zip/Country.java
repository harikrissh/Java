import java.util.*;
class Country{
	Set<String> H1=new HashSet<String>();
	
	public Set<String> storeCountryNames(String CountryName){
		H1.add(CountryName);
		return H1;
	}
	
	public String retrieveCountry(String CountryName){
		String found="";
		Iterator<String> itr=H1.iterator();
		while(itr.hasNext()){
			if(itr.next().equals(CountryName)){
				found=CountryName;
				break;
			}
		}
		return found;
	}
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Country country=new Country();
		Set<String> setObj=new HashSet<String>();

		System.out.println("Enter number of countries you want to add..");
		int num=s.nextInt();
		System.out.println("Enter country names..");
		for(int i=0;i<num;i++){
			String ctry=s.next();
			setObj=country.storeCountryNames(ctry);
		}
		System.out.println("\nCountries added to HashSet..\n"+setObj);

		System.out.println("\nEnter a CountryName..");
		String findCtry=s.next();
		String foundCtry=country.retrieveCountry(findCtry);
		if(foundCtry.equals(findCtry))
			System.out.println("\n"+foundCtry+" is present in HashSet");
		else
			System.out.println("\n"+findCtry+" is not available in HashSet.");

	}
}