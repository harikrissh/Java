import java.util.*;
class EvenNumbers{
	List<Integer> A1=new ArrayList<Integer>();
	List<Integer> A2=new ArrayList<Integer>();
	
	public List<Integer> storeEvenNumbers(int N){
		for(int i=2;i<=N;i+=2){
			A1.add(i);
		}
		return A1;
	}
	
	public List<Integer> printEvenNumbers(){
		Iterator<Integer> itr=A1.iterator();
		while(itr.hasNext()){
			A2.add(itr.next()*2);
		}
		return A2;
	}
	
	public int retrieveEvenNumbers(int N){
		int found=0;
		boolean flag=false;
		Iterator<Integer> itr=A1.iterator();
		while(itr.hasNext()){
			if(itr.next()==N){
				found=A1.indexOf(N);
				flag=true;
				break;
			}
		}
		if(!flag)
			return 0;
		return found;
	}
	
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		EvenNumbers evenNumbers=new EvenNumbers();
		List<Integer> list1=new ArrayList<Integer>();

		System.out.println("Enter range..");
		int n=s.nextInt();
		list1=evenNumbers.storeEvenNumbers(n);
		
		System.out.println("\nOriginal list(Even numbers upto "+ n+")..\n"+list1);
		list1=evenNumbers.printEvenNumbers();
		System.out.println("\nOriginal list multiplied by 2..\n"+list1);
		
		System.out.println("\nEnter a Number to retrieve in original list..");
		int num=s.nextInt();
		int retrievedNum=evenNumbers.retrieveEvenNumbers(num);
		if(retrievedNum!=0)
			System.out.println("\n"+num+" is found in index "+retrievedNum);
		else
			System.out.println("\nNumber "+num+" is not available in that list.");
	}
}